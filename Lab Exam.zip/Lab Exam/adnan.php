<!DOCTYPE HTML>
<html>
    <head></head>

    <body>
    <h1>Please fill up the form</form></h1>
        <hr>
        <form action="control/action.php method" method="POST">
            <table>
                <tr>
              <td><label for="fname">First Name:</label></td>                       
           <td><input type="text" id="fname" name="fname"></td>                                     
            </tr>
                <tr>
                        <td><label for="lname">Last Name:</label></td>                       
                    <td><input type="text" id="lname" name="lname"></td>                                     
                </tr>
              

                <tr>
                    <td><label for="email">Email:</label></td>                       
                    <td><input type="email" id="email" name="email"></td>                                  
                </tr>

                <tr>
                    <td><label for="gender">Gender:</label></td>                       
                    <td>
                        <input type="radio" id="ml" name="txt1" value="ml">
                        <label for="ml">Male</label>
                        <input type="radio" id="fl" name="txt1" value="fl">
                        <label for="fl">Female</label>
                        
                    </td>                                                                                        
                </tr>
                <tr>
              <td><label for="mbl">Mobile No:</label></td>                     
              <td><input type="text" id="mbl" name="mbl"></td>                                     
           <tr>
  
<td><label for="dob">Date of Birth:</label></td>     
<td> <input type="date" id="Date" name="date"> <td>
      
       <tr><tr>
              <td><label for="hsc">HSC results:</label></td>                     
              <td><input type="text" id="hsc" name="hsc"></td>                                     
           <tr>
           <tr>
              <td><label for="ssc">SSC results:</label></td>                     
              <td><input type="text" id="ssc" name="ssc"></td>                                     
           <tr>
               
          
             <tr>
                  <td>Select a Course You Want To Enroll:</td>
              <td>
  

             <select name="course" id="course">
             <option value="SELECT">Select</option>
              <option value="CSE">CSE</option>
             <option value="BBA">BBA</option>
              <option value="EEE">EEE</option>
              
                 </select>
                  </td>
                   </tr>

                   <tr>
                   <td></td>
                     </tr>

  

  <tr>
  <td>Chosee a Enrolling Year:</td>
                 <td>
  

             <select name="course" id="course">
        <option value="SELECT">Select</option>
          <option value="2021">2021</option>
          <option value="2022">2022</option>
              <option value="2023">2023</option>
              
                </select>
                   </td>
                   
                </tr>
                  <tr>
               <td></td>
                   </tr>

  
  <tr>
  <td>Chosee a Enrolling Season:</td>
  <td>
  

<select name="course" id="course">
  <option value="SELECT">Select</option>
  <option value="Summer">Summer</option>
  <option value="Spring">Spring</option>
  <option value="Fall">Fall</option>
  
</select>
</td>
</tr>
<tr>
 <td></td>
</tr>


  <tr>
   
  <td><button type="button" onclick="alert('Thank you')">Insert Data</button></td>
  </tr>
            </table>           
        </form>
    </body>
</html>